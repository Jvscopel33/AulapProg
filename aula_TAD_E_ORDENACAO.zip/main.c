#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "pessoa.h"

void imprimeNotas(char *n[], int tam)
{
    printf("{\n");
    for (int i = 0; i < tam; i++)
    {
        printf("%s\n", n[i]);
    }
    printf("}\n");
}

int comparaNotas(const void *a, const void *b)
{
    Pessoa *x = *(Pessoa **)a;
    Pessoa *z = *(Pessoa **)b;
    return strcmp(getNome(x), getNome(z));
}

int main()
{
    Pessoa *P1 = criaPessoa("JOAO", "321.321.321", 'M');
    Pessoa *P2 = criaPessoa("MARIA", "123.123.123", 'F');
    Pessoa *P3 = criaPessoa("LULA", "30.30.30", 'M');
    Pessoa *P4 = criaPessoa("BOLSONARO", "121.121.121", 'M');
    Pessoa *P5 = criaPessoa("MARCAL", "67.67.67.67", 'M');

    Pessoa **listaPessoas = (Pessoa **)calloc(5, sizeof(Pessoa *));
    int qtdPessoas = 5;

    listaPessoas[0] = P1;
    listaPessoas[1] = P2;
    listaPessoas[2] = P3;
    listaPessoas[3] = P4;
    listaPessoas[4] = P5;

    // ORDENA
    qsort(listaPessoas, qtdPessoas, sizeof(listaPessoas[0]), comparaNotas);

    for (int i = 0; i < qtdPessoas; i++)
    {
        printPessoa(listaPessoas[i]);
    }
    // DESALOCA
    for (int i = 0; i < qtdPessoas; i++)
    {
        destroiPessoa(listaPessoas[i]);
    }
    free(listaPessoas);

    return 0;
}