#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "pessoa.h"

#define MAX_NOME 100
#define MAX_CPF 18

struct pessoa
{
    char nome[MAX_NOME];
    char cpf[MAX_CPF];
    char genero;
};

Pessoa *criaPessoa(char *nome, char *cpf, char genero)
{
    Pessoa *p = (Pessoa *)calloc(1, sizeof(Pessoa));
    strcpy(p->nome, nome);
    strcpy(p->cpf, cpf);
    p->genero = genero;
    return p;
}

Pessoa *lePessoa()
{
    Pessoa p;
    scanf(" %[^\n]\n", p.nome);
    scanf(" %[^\n]\n", p.cpf);
    scanf(" %c\n", &p.genero);
    return criaPessoa(p.nome, p.cpf, p.genero);
}

void printPessoa(void *data)
{
    Pessoa *p = (Pessoa *)data;
    printf("-> NOME - %s \n-> CPF - %s\n-> GENERO - %c\n", p->nome, p->cpf, p->genero);
}

void destroiPessoa(void *data)
{
    Pessoa *p = (Pessoa *)data;
    free(p);
}