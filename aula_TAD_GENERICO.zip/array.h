#ifndef _ARRAY_H
#define _ARRAY_H

typedef struct array Array;
typedef void (*fptr_desaloca)(void *);
typedef void (*fprt_imprime)(void *);

Array *criaArray(fptr_desaloca desalocaData);
void addElemento(Array *a, void *elem);
void *getElemArray(Array *a, int pos);
int getTamArray(Array *a);
void printArray(Array *a, fprt_imprime printData);
void liberaArray(Array *a);
#endif