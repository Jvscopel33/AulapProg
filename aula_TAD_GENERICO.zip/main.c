#include <stdio.h>
#include <stdlib.h>
#include "array.h"
#include "pessoa.h"

int main()
{
    Array *listaPessoa = criaArray(destroiPessoa);

    while (1)
    {
        char cmd;
        scanf(" %c\n", &cmd);
        if (cmd == 'A')
        {
            addElemento(listaPessoa, lePessoa());
        }
        else
        {
            break;
        }
    }
    
    printArray(listaPessoa, printPessoa);
    liberaArray(listaPessoa);
    return 0;
}