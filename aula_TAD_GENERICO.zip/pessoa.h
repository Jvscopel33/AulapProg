#ifndef _PESSOA_H
#define _PESSOA_H

typedef struct pessoa Pessoa;

Pessoa *criaPessoa(char *nome, char *cpf, char gener);
Pessoa *lePessoa();
void destroiPessoa(void *data);
void printPessoa(void *data);

#endif