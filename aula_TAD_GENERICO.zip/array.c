#include <stdio.h>
#include <stdlib.h>
#include "array.h"

struct array
{
    void **data;
    int tam;
    fptr_desaloca desalocaData;
};

Array *criaArray(fptr_desaloca desalocaData)
{
    Array *a = (Array *)calloc(1, sizeof(Array));
    a->tam = 0;
    a->data = NULL;
    a->desalocaData = desalocaData;
    return a;
}

void addElemento(Array *a, void *elem)
{
    a->data = realloc(a->data, (a->tam + 1) * sizeof(void *));
    a->data[a->tam] = elem;
    a->tam++;
}

void *getElemArray(Array *a, int pos)
{
    if (pos >= 0 && pos < a->tam)
    {
        return a->data[pos];
    }
    return NULL;
}

int getTamArray(Array *a)
{
    return a->tam;
}

void printArray(Array *a, fprt_imprime printData)
{
    printf("\n---COMECO ARAAY---\n\n");
    for (int i = 0; i < a->tam; i++)
    {
        printData(a->data[i]);
    }
    printf("\n---FIM ARAAY---\n");
}

void liberaArray(Array *a)
{
    for (int i = 0; i < a->tam; i++)
    {
        a->desalocaData(a->data[i]);
    }
    free(a->data);
    free(a);
}