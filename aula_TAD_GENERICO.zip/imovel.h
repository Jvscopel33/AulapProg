#ifndef _IMOVEL_H
#define _IMOVEL_H

typedef struct imovel Imovel;


#endif