#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "imovel.h"

#define MAX_ENDERECO 100

struct imovel
{
    char endereco[MAX_ENDERECO];
    float valorDoImovel
};

Imovel *criaImovel(char *endereco, float valorDoImovel)
{
    
}